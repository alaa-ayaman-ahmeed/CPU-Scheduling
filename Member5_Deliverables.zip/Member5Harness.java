import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 * Member 5 - Test harness for SJF (SRTF) and the Adaptive Container Scheduler (ACS).
 *
 * - SJF runs call SJFScheduler.schedule() directly (team code, unmodified).
 * - ACS runs reuse the team's Tier2Scheduler + AgingPriorityCalculator unmodified.
 *   Tier 1 (Round Robin) is replayed by the harness with exactly the logic of
 *   Tier1Scheduler.executeTier1, extended with a context-switch (CS) cost.
 *   At CS = 0 the replay is cross-checked against the real Tier1Scheduler
 *   (identical Gantt segments and first-start/finish times) - see validate().
 *
 * CS rule (same as SJFScheduler): a CS of `cs` time units is inserted whenever the
 * CPU switches to a DIFFERENT process than the one that ran last. No CS before the
 * very first dispatch or after an idle gap.
 *
 * Output: CSV files written to the directory given as args[0].
 */
public class Member5Harness {

    // ------------------------------------------------------------ data holders
    static class Wl {
        String id, name, desc;
        String[][] p; // {pid, arrival, burst, priority}
        Wl(String id, String name, String desc, String[][] p) {
            this.id = id; this.name = name; this.desc = desc; this.p = p;
        }
    }
    static class Seg {
        String label; int start, end, tier; // tier: 0 = none (CS/IDLE/SJF), 1, 2
        Seg(String l, int s, int e, int t) { label = l; start = s; end = e; tier = t; }
    }
    static class Ev {
        int time; String type, pid, detail;
        Ev(int t, String ty, String p, String d) { time = t; type = ty; pid = p; detail = d; }
    }
    static class Row {
        String pid; int arr, burst, prio, start, finish;
        int tat() { return finish - arr; }
        int wt() { return tat() - burst; }
        int rt() { return start - arr; }
    }
    static class Run {
        String algo; int q, cs, aging;
        List<Seg> segs = new ArrayList<>();
        List<Row> rows = new ArrayList<>();
        List<Ev> evs = new ArrayList<>();
        int demotions = 0;
        double avg(int which) {
            double s = 0;
            for (Row r : rows) s += which == 0 ? r.wt() : which == 1 ? r.tat() : r.rt();
            return s / rows.size();
        }
        int makespan() { return segs.get(segs.size() - 1).end; }
        int sum(String label) {
            int s = 0;
            for (Seg g : segs) if (g.label.equals(label)) s += g.end - g.start;
            return s;
        }
        int count(String label) {
            int s = 0;
            for (Seg g : segs) if (g.label.equals(label)) s++;
            return s;
        }
    }

    // ------------------------------------------------------------ workloads
    static List<Wl> workloads() {
        List<Wl> w = new ArrayList<>();
        w.add(new Wl("W1", "Mixed arrivals",
            "Member 2's Tier1Test data set: staggered arrivals, one short and three long jobs.",
            new String[][]{{"P1","0","8","3"},{"P2","1","5","1"},{"P3","4","2","2"},{"P4","10","6","4"}}));
        w.add(new Wl("W2", "Simultaneous arrival",
            "Member 2's Tier1IntegrationTest data set: everything arrives at t = 0.",
            new String[][]{{"P1","0","8","3"},{"P2","0","5","1"},{"P3","0","2","2"}}));
        w.add(new Wl("W3", "SJF Test Case 1",
            "The no-preemption case from the SJF report (priorities added for ACS).",
            new String[][]{{"P1","0","4","2"},{"P2","1","7","3"},{"P3","3","2","1"}}));
        w.add(new Wl("W4", "SJF Test Case 2",
            "The preemption case from the SJF report (priorities added for ACS).",
            new String[][]{{"P1","0","8","3"},{"P2","2","4","2"},{"P3","4","1","1"}}));
        w.add(new Wl("W5", "Starvation stress",
            "One very long low-priority job competing with a stream of shorter, higher-priority jobs.",
            new String[][]{{"P1","0","20","5"},{"P2","0","9","1"},{"P3","1","7","2"},
                           {"P4","2","6","3"},{"P5","3","12","4"},{"P6","5","3","1"}}));
        w.add(new Wl("W6", "Idle gap",
            "The CPU becomes idle between t = 3 and t = 10; tests idle handling.",
            new String[][]{{"P1","0","3","2"},{"P2","10","4","1"},{"P3","11","6","3"}}));
        w.add(new Wl("W7", "Ties",
            "Identical jobs: exercises every tie-breaking rule (arrival, entry time, id).",
            new String[][]{{"P1","0","6","2"},{"P2","0","6","2"},{"P3","0","6","2"},{"P4","2","6","2"}}));
        return w;
    }

    // ------------------------------------------------------------ SJF
    static Run runSJF(Wl w, int cs) {
        List<SJFScheduler.Process> in = new ArrayList<>();
        for (String[] p : w.p)
            in.add(new SJFScheduler.Process(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2])));
        SJFScheduler.Result res = SJFScheduler.schedule(in, cs);
        Run r = new Run();
        r.algo = "SJF"; r.q = 0; r.cs = cs; r.aging = 0;
        for (SJFScheduler.Segment s : res.timeline) r.segs.add(new Seg(s.label, s.start, s.end, 0));
        for (int i = 0; i < res.processes.size(); i++) {
            SJFScheduler.Process p = res.processes.get(i);
            Row row = new Row();
            row.pid = p.id; row.arr = p.arrivalTime; row.burst = p.burstTime;
            row.prio = Integer.parseInt(w.p[i][3]);
            row.start = p.firstStartTime; row.finish = p.finishTime;
            r.rows.add(row);
        }
        return r;
    }

    // ------------------------------------------------------------ ACS helpers
    static List<ACSProcess> make(Wl w) {
        List<ACSProcess> l = new ArrayList<>();
        for (String[] p : w.p)
            l.add(new ACSProcess(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])));
        return l;
    }

    static PrintStream REAL_OUT = System.out;
    static PrintStream NULL_OUT = new PrintStream(new OutputStream() { public void write(int b) {} });

    /** ACS: Tier 1 replayed by the harness (with CS), Tier 2 = team's Tier2Scheduler + aging. */
    static Run runACS(Wl w, int q, int cs, int agingInterval) {
        System.setOut(NULL_OUT); // Tier2Scheduler prints on every call
        try {
            List<ACSProcess> procs = make(w);
            Run r = new Run();
            r.algo = "ACS"; r.q = q; r.cs = cs; r.aging = agingInterval;
            Map<String, Integer> firstStart = new HashMap<>();

            Tier2Scheduler tier2 = new Tier2Scheduler();
            Tier2Scheduler.PriorityCalculator aging = new AgingPriorityCalculator(agingInterval, 1);
            List<ACSProcess> t2members = new ArrayList<>(); // mirror of the private Tier 2 queue

            List<ACSProcess> incoming = new ArrayList<>(procs);
            incoming.sort(Comparator.comparingInt(p -> p.arrivalTime));
            Deque<ACSProcess> queue = new ArrayDeque<>();
            int nxt = 0, time = 0;
            String last = null;

            // ---------------- Tier 1: Round Robin, demote after one quantum
            while (nxt < incoming.size() || !queue.isEmpty()) {
                while (nxt < incoming.size() && incoming.get(nxt).arrivalTime <= time) {
                    ACSProcess a = incoming.get(nxt++);
                    queue.add(a);
                    r.evs.add(new Ev(a.arrivalTime, "ARRIVE", a.processId, "burst=" + a.burstTime));
                }
                if (queue.isEmpty()) {
                    int nextArr = incoming.get(nxt).arrivalTime;
                    r.segs.add(new Seg("IDLE", time, nextArr, 0));
                    time = nextArr; last = null;
                    continue;
                }
                ACSProcess p = queue.poll();
                if (last != null && !last.equals(p.processId) && cs > 0) {
                    r.segs.add(new Seg("CS", time, time + cs, 0));
                    time += cs;
                }
                int exec = Math.min(q, p.remainingTime);
                int s = time, e = time + exec;
                firstStart.putIfAbsent(p.processId, s);
                p.remainingTime -= exec;
                time = e;
                r.segs.add(new Seg(p.processId, s, e, 1));
                last = p.processId;
                if (p.remainingTime == 0) {
                    p.finishTime = time; p.completed = true;
                    r.evs.add(new Ev(time, "DONE", p.processId, "tier=1"));
                } else {
                    tier2.addTier1Process(p, time);
                    t2members.add(p);
                    r.demotions++;
                    r.evs.add(new Ev(time, "DEMOTE", p.processId, "remaining=" + p.remainingTime));
                }
            }

            // ---------------- Tier 2: non-preemptive priority with aging
            while (!tier2.isEmpty()) {
                ACSProcess sel = tier2.selectNext(time, aging);
                StringBuilder d = new StringBuilder();
                for (ACSProcess m : t2members) {
                    if (d.length() > 0) d.append(';');
                    d.append(m.processId).append(':').append(m.initialPriority).append('>').append(m.effectivePriority);
                }
                r.evs.add(new Ev(time, "T2SELECT", sel.processId, d.toString()));
                t2members.remove(sel);
                if (last != null && !last.equals(sel.processId) && cs > 0) {
                    r.segs.add(new Seg("CS", time, time + cs, 0));
                    time += cs;
                }
                int s = time;
                firstStart.putIfAbsent(sel.processId, s);
                time = tier2.executeSelected(sel, time);
                r.segs.add(new Seg(sel.processId, s, time, 2));
                r.evs.add(new Ev(time, "DONE", sel.processId, "tier=2"));
                last = sel.processId;
            }

            for (ACSProcess p : procs) {
                Row row = new Row();
                row.pid = p.processId; row.arr = p.arrivalTime; row.burst = p.burstTime;
                row.prio = p.initialPriority; row.start = firstStart.get(p.processId);
                row.finish = p.finishTime;
                r.rows.add(row);
            }
            return r;
        } finally {
            System.setOut(REAL_OUT);
        }
    }

    // ------------------------------------------------------------ validation vs team code (CS = 0)
    static String validate(Wl w, int q) {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        System.setOut(new PrintStream(buf));
        List<ACSProcess> procs = make(w);
        Tier1Scheduler t1 = new Tier1Scheduler();
        Tier2Scheduler t2 = new Tier2Scheduler();
        int time = t1.executeTier1(procs, q, 0, t2);
        Map<String, Integer> first = new HashMap<>();
        for (ACSProcess p : procs) first.put(p.processId, p.startTime); // snapshot BEFORE Tier 2 overwrites it
        Tier2Scheduler.PriorityCalculator aging = new AgingPriorityCalculator(4, 1);
        while (!t2.isEmpty()) {
            ACSProcess s = t2.selectNext(time, aging);
            time = t2.executeSelected(s, time);
        }
        System.setOut(REAL_OUT);

        List<String> team = new ArrayList<>();
        Matcher m = Pattern.compile("(\\S+) executes from (\\d+) to (\\d+)").matcher(buf.toString());
        while (m.find()) team.add(m.group(1) + "[" + m.group(2) + "-" + m.group(3) + "]");

        Run mine = runACS(w, q, 0, 4);
        List<String> sim = new ArrayList<>();
        for (Seg g : mine.segs)
            if (!g.label.equals("IDLE") && !g.label.equals("CS"))
                sim.add(g.label + "[" + g.start + "-" + g.end + "]");

        boolean ok = team.equals(sim);
        for (int i = 0; i < procs.size() && ok; i++) {
            ACSProcess p = procs.get(i);
            Row r = mine.rows.get(i);
            if (r.finish != p.finishTime || r.start != first.get(p.processId)) ok = false;
        }
        return (ok ? "PASS" : "FAIL") + "  " + w.id + "  Q=" + q + "  segments=" + team.size();
    }

    // ------------------------------------------------------------ output
    static String f(double d) { return String.format(Locale.ROOT, "%.4f", d); }

    public static void main(String[] args) throws Exception {
        String dir = args.length > 0 ? args[0] : "out";
        new File(dir).mkdirs();
        int[] qs = {1, 2, 3, 4, 5, 6, 8, 10};
        int[] css = {0, 1, 2, 3, 4};
        int[] agings = {1, 2, 4, 8, 1000};

        PrintWriter wl = new PrintWriter(dir + "/workloads.csv");
        PrintWriter runs = new PrintWriter(dir + "/runs.csv");
        PrintWriter procs = new PrintWriter(dir + "/procs.csv");
        PrintWriter segs = new PrintWriter(dir + "/segments.csv");
        PrintWriter evs = new PrintWriter(dir + "/events.csv");
        PrintWriter val = new PrintWriter(dir + "/validation.txt");

        wl.println("workload,name,pid,arrival,burst,priority,description");
        runs.println("workload,algo,q,cs,aging,avg_wt,avg_tat,avg_rt,makespan,cs_time,idle_time,num_cs,demotions");
        procs.println("workload,algo,q,cs,aging,pid,arrival,burst,priority,first_start,finish,tat,wt,rt");
        segs.println("workload,algo,q,cs,aging,label,start,end,tier");
        evs.println("workload,algo,q,cs,aging,time,type,pid,detail");

        int pass = 0, fail = 0;
        for (Wl w : workloads()) {
            for (String[] p : w.p)
                wl.println(w.id + "," + w.name + "," + p[0] + "," + p[1] + "," + p[2] + "," + p[3] + "," + w.desc.replace(",", ";"));

            List<Run> all = new ArrayList<>();
            for (int cs : css) all.add(runSJF(w, cs));
            for (int q : qs) for (int cs : css) all.add(runACS(w, q, cs, 4));
            for (int ag : agings) if (ag != 4) all.add(runACS(w, 3, 0, ag));

            for (Run r : all) {
                String key = w.id + "," + r.algo + "," + r.q + "," + r.cs + "," + r.aging;
                runs.println(key + "," + f(r.avg(0)) + "," + f(r.avg(1)) + "," + f(r.avg(2)) + ","
                        + r.makespan() + "," + r.sum("CS") + "," + r.sum("IDLE") + "," + r.count("CS") + "," + r.demotions);
                for (Row x : r.rows)
                    procs.println(key + "," + x.pid + "," + x.arr + "," + x.burst + "," + x.prio + ","
                            + x.start + "," + x.finish + "," + x.tat() + "," + x.wt() + "," + x.rt());
                for (Seg g : r.segs)
                    segs.println(key + "," + g.label + "," + g.start + "," + g.end + "," + g.tier);
                for (Ev e : r.evs)
                    evs.println(key + "," + e.time + "," + e.type + "," + e.pid + "," + e.detail);
            }
            for (int q : qs) {
                String line = validate(w, q);
                val.println(line);
                if (line.startsWith("PASS")) pass++; else fail++;
            }
        }
        val.println("TOTAL PASS=" + pass + " FAIL=" + fail);
        for (PrintWriter p : new PrintWriter[]{wl, runs, procs, segs, evs, val}) p.close();
        System.out.println("validation: PASS=" + pass + " FAIL=" + fail);
    }
}
