"""Independent re-implementation of SRTF and ACS to cross-check the Java harness output."""
import pandas as pd, math, sys
W = pd.read_csv('out/workloads.csv'); R = pd.read_csv('out/runs.csv'); P = pd.read_csv('out/procs.csv')

def wl(w):
    d = W[W.workload==w]
    return [(r.pid, int(r.arrival), int(r.burst), int(r.priority)) for r in d.itertuples()]

def srtf(procs, cs):
    rem = {p[0]: p[2] for p in procs}; arr = {p[0]: p[1] for p in procs}
    first, fin = {}, {}
    t, last, done = 0, None, 0
    def pick(t):
        c = [(rem[i], arr[i], i) for i in rem if arr[i] <= t and rem[i] > 0]
        return min(c)[2] if c else None
    while done < len(procs):
        s = pick(t)
        if s is None:
            t = min(arr[i] for i in rem if rem[i] > 0); last = None; continue
        if last is not None and last != s and cs > 0:
            t += cs; s = pick(t)
            if s is None: last = None; continue
        first.setdefault(s, t); rem[s] -= 1; t += 1
        if rem[s] == 0: fin[s] = t; done += 1
        last = s
    return first, fin

def acs(procs, q, cs, ag):
    arr = {p[0]: p[1] for p in procs}; bur = {p[0]: p[2] for p in procs}; pri = {p[0]: p[3] for p in procs}
    rem = dict(bur); first, fin, entry = {}, {}, {}
    order = sorted(procs, key=lambda p: p[1])   # stable
    queue, i, t, last = [], 0, 0, None
    while i < len(order) or queue:
        while i < len(order) and order[i][1] <= t: queue.append(order[i][0]); i += 1
        if not queue: t = order[i][1]; last = None; continue
        p = queue.pop(0)
        if last is not None and last != p and cs: t += cs
        first.setdefault(p, t); x = min(q, rem[p]); t += x; rem[p] -= x; last = p
        if rem[p] == 0: fin[p] = t
        else: entry[p] = t
    while entry:
        eff = {p: max(1, pri[p] - (t - entry[p]) // ag) for p in entry}
        s = min(entry, key=lambda p: (eff[p], entry[p], p))
        del entry[s]
        if last is not None and last != s and cs: t += cs
        first.setdefault(s, t); t += rem[s]; rem[s] = 0; fin[s] = t; last = s
    return first, fin

bad = 0; n = 0
for r in R.itertuples():
    procs = wl(r.workload)
    f, fi = srtf(procs, r.cs) if r.algo == 'SJF' else acs(procs, r.q, r.cs, r.aging)
    d = P[(P.workload==r.workload)&(P.algo==r.algo)&(P.q==r.q)&(P.cs==r.cs)&(P.aging==r.aging)]
    n += 1
    for x in d.itertuples():
        if f[x.pid] != x.first_start or fi[x.pid] != x.finish:
            bad += 1; print('MISMATCH', r.workload, r.algo, r.q, r.cs, r.aging, x.pid, f[x.pid], x.first_start, fi[x.pid], x.finish)
    # identities
    for x in d.itertuples():
        assert x.tat == x.finish - x.arrival and x.wt == x.tat - x.burst and x.rt == x.first_start - x.arrival
print(f'cross-checked {n} runs, mismatches: {bad}')
